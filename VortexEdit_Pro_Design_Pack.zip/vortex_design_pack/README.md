# VortexEdit Pro - Design Pack

Visual reference + ready-to-use assets for the full interface (dark, purple #8B5CF6 + gold #F5C451).

## Contents
- `screens/` HTML mockups (open in a browser, needs `shared/style.css` next to it):
  01-media, 02-audio, 03-text, 04-stickers, 05-effects, 06-transitions, 07-filters, 08-adjust, 09-templates, 10-ai
  (each = full editor with that left tab open + its matching Inspector),
  11-export, 12-autoedit-type, 13-autoedit-progress, 14-autoedit-compare, 15-quick-edit,
  16-settings, 17-model-manager, 18-splash-about, 19-tools-reference.
- `theme/tokens.json` colors, radii, spacing, fonts, layout sizes.
- `theme/vortex_dark.qss` PySide6 stylesheet (use `app.setStyleSheet(...)`).
- `icons/*.svg` 40 icons, stroke `currentColor`: recolor at load time (replace `currentColor` with a hex) before giving them to QIcon/QSvgRenderer.

## Qt mapping (objectName / property)
- Panels: `objectName="Panel"` | top bar: `TopBar` | left rail buttons: `RailButton` (checkable, exclusive)
- Gold Export button: `ExportButton` | purple primary buttons: `setProperty("primary", True)`
- Timeline toolbar buttons: `ToolButton` (checkable for magnet/snap) | muted labels: `setProperty("muted", True)`
- Layout (px): window 1440x900, top bar 56, rail 72, drawer 284, inspector 316, timeline 316.
- Timeline track colors: video #6D4AD8, overlay #4F46E5, text #A78BFA, filter #F5C451 (gold outline), audio #3B82A0; playhead purple with glow.
- Arabic mode mirrors the shell (rail, drawer, inspector) but the timeline stays left-to-right.

## Notes
- HTML files are design references, not app code. Rebuild them with Qt widgets; do not embed them as web views.
- Not tested inside Qt; QSS may need small tweaks per widget.

## Added screens
- 20-home: the screen the app opens on (New project, Open project, Templates, Auto-Edit, Recent projects).
- 21-new-project: new project dialog.
- 22-top-menus: File / Edit / View / Help menus with icons and shortcuts.
- Editor timeline has NO filter or transition dropdowns: transitions are diamond markers between clips (Video track); filters/effects are gold blocks on the Filter track.
